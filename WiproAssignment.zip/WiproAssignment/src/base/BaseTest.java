package base;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;
import utils.Utility;


public class BaseTest { 
	public static AndroidDriver<AndroidElement> driver;
	public static String platform;
	public static String deviceName;
	public static String appPackage;		
	public static String aapActivity;		


	public BaseTest() {			
		platform = configValue("platform");
		deviceName = configValue("device");
		appPackage = configValue("appPackage");
		aapActivity = configValue("aapActivity");						

	}	

	private String configValue(String key) {
		String value = null;
		try {
			value = Utility.readPropertiesFile("config.properties", key);			
		} catch (Exception e) {
			System.out.println("Exception in method configValue "+e.getMessage());
		}
		return value;
	}

	public static void getApp()  {
		try {
			DesiredCapabilities cap=new DesiredCapabilities();		
			cap.setCapability(MobileCapabilityType.PLATFORM, platform );
			cap.setCapability(MobileCapabilityType.DEVICE_NAME,deviceName);
			cap.setCapability("appPackage",appPackage);
			cap.setCapability("appActivity",aapActivity);
			cap.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT,500);
			cap.setCapability("autoAcceptAlerts", true);
			//cap.setCapability("autoWebview", true);
			driver=new AndroidDriver<AndroidElement>(new URL("http://127.0.0.1:4723/wd/hub"), cap);
			driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);	
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}			
}

