package pageObjects;

public class ShippingAddressObjects {

	public static final String btnHome ="com.ebay.mobile:id/home";
	public static final String btnLogo = "com.ebay.mobile:id/logo";
	public static final String txtUsername = "com.ebay.mobile:id/edit_text_username";
	public static final String txtPassword = "com.ebay.mobile:id/edit_text_password";
	public static final String btnSignIn = "com.ebay.mobile:id/button_sign_in";
	
	
}
