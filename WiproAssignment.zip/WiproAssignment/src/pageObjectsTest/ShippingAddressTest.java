package pageObjectsTest;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.remote.MobileCapabilityType;
import pageObjects.ShippingAddressObjects;
import reportManager.ExtentManager;

public class ShippingAddressTest extends ExtentManager{
	
	//Initializing driver
	AndroidDriver<AndroidElement> driver;
	//Test data
	String usernamestr="ram.kaup@gmail.com";	
	String passwordstr="Test@123";
	
	 
		@BeforeClass
		public void setup() throws MalformedURLException {	
			
			DesiredCapabilities cap=new DesiredCapabilities();		// Creating object for desired capabilities 
			cap.setCapability(MobileCapabilityType.PLATFORM,    "Android"); // Setting platform
			cap.setCapability(MobileCapabilityType.DEVICE_NAME,"emulator-5554");// Setting Device name
			cap.setCapability("appPackage","com.ebay.mobile"); // Setting app package of app under test
			cap.setCapability("appActivity","com.ebay.mobile.activities.MainActivity"); // Setting app activity to open at the launch of application
			cap.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT,300); // Setting timeout for 300seconds if action performed
			cap.setCapability("autoAcceptAlerts", true); // Accept any alerts automatically
			//cap.setCapability("autoWebview", true);	
			// Sending capability and communicating to port via 
			//JSON wire protocol
			driver=new AndroidDriver<AndroidElement>(new URL("http://127.0.0.1:4723/wd/hub"), cap); 
			
			//Setting implicit timeout for driver
			driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);			
		}
		
		@Test
		public void updateShipingAddress() throws MalformedURLException, InterruptedException {
			// Code to sign in to the application
			driver.findElementById(ShippingAddressObjects.btnHome).click();		
			driver.findElementById(ShippingAddressObjects.btnLogo).click();
			driver.findElementById(ShippingAddressObjects.txtUsername).click();
			driver.findElementById(ShippingAddressObjects.txtUsername).sendKeys(usernamestr);			
			driver.findElementById(ShippingAddressObjects.txtPassword).click();
			driver.findElementById(ShippingAddressObjects.txtPassword).sendKeys(passwordstr);					
			driver.findElementById(ShippingAddressObjects.btnSignIn).click();			
			WebDriverWait wait1=new WebDriverWait(driver,120);
			wait1.until(ExpectedConditions.visibilityOf(driver.findElementById("com.ebay.mobile:id/button_google_deny")));
			driver.findElementById("com.ebay.mobile:id/button_google_deny").click();
			
			driver.findElementById(ShippingAddressObjects.btnHome).click();
			
			driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\"Settings\").instance(0))").click();			
			driver.findElementByAndroidUIAutomator("text(\"Shipping address\")").click();
			
			driver.findElementByAndroidUIAutomator("text(\"Enter a new address\")").click();
			
			
			driver.findElementById("com.ebay.mobile:id/address_edit_country_layout").click();
			
			driver.findElementById("com.ebay.mobile:id/filter").sendKeys("Australia");
			driver.findElementById("com.ebay.mobile:id/check_country").click();
			
			
			driver.findElementById("com.ebay.mobile:id/address_edit_name").sendKeys("RandomName");
			driver.findElementById("com.ebay.mobile:id/address_edit_phone").sendKeys("0431570156");
			driver.findElementById("com.ebay.mobile:id/address_edit_street").sendKeys("street1");
			
			driver.pressKeyCode(AndroidKeyCode.BACK);
			driver.findElementById("com.ebay.mobile:id/address_edit_street2").sendKeys("street2");
			driver.pressKeyCode(AndroidKeyCode.BACK);
			driver.findElementById("com.ebay.mobile:id/address_edit_city").sendKeys("Sydey");
			driver.pressKeyCode(AndroidKeyCode.BACK);
			driver.findElementById("com.ebay.mobile:id/address_edit_state").click();
			
			driver.findElementByAndroidUIAutomator("text(\"Australian Capital Territory\")").click();
			
			driver.findElementById("com.ebay.mobile:id/address_edit_postal_code").sendKeys("2000");	
			
			driver.findElementByAndroidUIAutomator("text(\"Save\")").click();
		}	
	
		@AfterClass
		public void teardown() {	
			
			driver.quit();	
		}		
			
}



