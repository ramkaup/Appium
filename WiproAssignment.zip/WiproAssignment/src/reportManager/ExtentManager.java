package reportManager;

import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import javax.imageio.ImageIO;

import com.relevantcodes.extentreports.DisplayOrder;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.relevantcodes.extentreports.NetworkMode;

public class ExtentManager {
	public static int ssCounter=1;
	public static String screenShot = "";
	public static String folderPath ="";
	public static String reportLocation = "";
	public static ExtentReports extentSuite;
	public static ExtentTest loggerSuite; 
	public static String htmlPath= "";
	public static LogStatus overallStatus;
	
	public static ExtentReports Instance(String testName)
	{
		ExtentReports extent;
		Date date =new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("MMddyyyy-HHmmss") ;
		
		
		String curDate = dateFormat.format(date);
		File extentConfig = new File(System.getProperty("user.dir")+"\\config\\extentConfigSuite.xml");
		reportLocation = folderPath+testName+"-" +curDate;
		
		File file = new File(reportLocation);
		file.mkdir();
		screenShot = reportLocation +"\\ScreenShot";
		htmlPath=reportLocation+"\\"+testName+curDate+".html";
		extent = new ExtentReports(reportLocation+"\\"+testName+curDate+".html", false, DisplayOrder.NEWEST_FIRST, NetworkMode.OFFLINE);
		extent.loadConfig(extentConfig);
		return extent;
	}

	public static void captureScreenShot(ExtentTest logger){

		String format = "png";
		File file = new File(screenShot);
		file.mkdir();
		String fileName = screenShot+"\\SS"+ssCounter++ +"." + format;
		try {

			Robot robot = new Robot();

			Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
			BufferedImage screenFullImage = robot.createScreenCapture(screenRect);
			ImageIO.write(screenFullImage, format, new File(fileName));

			String screenshot_path = fileName;
			String image= logger.addScreenCapture(screenshot_path);
			logger.log(LogStatus.PASS,image);

		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	public static void tearDemo(ExtentTest logger, ExtentReports extent ){
		 overallStatus =logger.getRunStatus();
		extent.endTest(logger);
		extent.flush();            
	} 
	
	public static void reportFolderGenerator() {
		Date date =new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("MMddyyyy-HHmmss") ;
		String curDate = dateFormat.format(date);
		String ReportFilePath = System.getProperty("user.dir")+"\\Reports\\";		
		 folderPath = ReportFilePath+"Results_"+ curDate+"\\";
		if(!(new File(folderPath).exists())) {
			new File(folderPath).mkdir();
		}
	}

	
	public static ExtentReports setupSuite()
	{		
		reportFolderGenerator();
		reportLocation = folderPath+"Automation result summary";		
		File file = new File(reportLocation);
		File extentConfig = new File(System.getProperty("user.dir")+"\\config\\extentConfigSuite.xml");
		file.mkdir();		
		extentSuite = new ExtentReports(reportLocation+"\\"+"Automation result summary.html", false, DisplayOrder.OLDEST_FIRST, NetworkMode.OFFLINE);
		extentSuite.loadConfig(extentConfig);
		HashMap <String, String> info = new HashMap<String,String>();
		info.put("Document Title", "Automation Report Suite");		
		extentSuite.addSystemInfo(info);	
		return extentSuite;
	}
	
	public static void tearDownSuite(ExtentTest logger, ExtentReports extent,String testName ){		
		loggerSuite.log(overallStatus, "<a href='file:///"+htmlPath+"' target=-blank>View report : "+testName+"</a></font>" );
		extentSuite.endTest(loggerSuite);
		extentSuite.flush();            
	} 
}